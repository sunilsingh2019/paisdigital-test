-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: lamp
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enquiry` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `firstname` varchar(5000) COLLATE latin1_general_ci NOT NULL,
  `lastname` varchar(5000) COLLATE latin1_general_ci NOT NULL,
  `jobtitle` varchar(500) COLLATE latin1_general_ci DEFAULT NULL,
  `company` varchar(500) COLLATE latin1_general_ci DEFAULT NULL,
  `email` varchar(1000) COLLATE latin1_general_ci NOT NULL,
  `phone` varchar(400) COLLATE latin1_general_ci NOT NULL,
  `insert_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (50,'Book demo','sunil','singh','developer','Bang','sunilsingh2019@gmail.com','0452139110','2021-12-13 20:17:14'),(51,'Book demo','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-13 20:25:31'),(52,'','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-13 20:27:33'),(53,'','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-13 21:02:48'),(54,'Get in touch','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-13 22:17:11'),(55,'Book demo','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-13 22:35:22'),(56,'Book demo','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-13 22:36:06'),(57,'demo','sunil','singh','developer','Bang','sunilsingh2019@gmail.com','0452139110','2021-12-14 00:33:26'),(58,'demo','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-14 01:15:17'),(59,'demo','sunil','singh','developer','Bang','sunilsingh2019@gmail.com','0452139110','2021-12-15 01:10:53'),(60,'demo','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-15 01:12:22'),(61,'demo','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-15 01:13:09'),(62,'demo','sunil','singh','developer','Bang','sunilsingh2019@gmail.com','0452139110','2021-12-15 01:19:48'),(63,'contact','sunil','singh','developer','Bang','sunilsingh2019@gmail.com','0452139110','2021-12-15 01:20:15'),(64,'contact','sunil','singh','developer','Bang','sunilsingh2019@gmail.com','0452139110','2021-12-15 01:30:27'),(65,'demo','Aastha','singh','developer','Bang','sunilsingh2019@gmail.com','0452139110','2021-12-15 01:31:14'),(66,'demo','su','singh','Dev','Nextgen','sunil@bang.com.au','0452139110','2021-12-15 01:34:40'),(67,'demo','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-15 06:18:09'),(68,'demo','sunil','singh','Developer','Bang','sunilsingh2019@gmail.com','0452139110','2021-12-15 20:15:02'),(69,'demo','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-15 20:17:41'),(70,'demo','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-15 21:44:32'),(71,'demo','sunil','singh','sdf','skdjf','sunilsingh2019@gmail.com','0452139110','2022-03-07 03:02:21'),(72,'contact','test','test','test','test','test@gmail.com','423423432','2024-08-11 08:07:43'),(73,'demo','sdf','asdf','test','sdf','asdf@gmail.com','345','2024-08-11 08:14:16'),(74,'demo','sdf','asdf','test','sdf','asdf@gmail.com','345','2024-08-11 08:14:56'),(75,'contact','sdf','sdf','sdf','sdf','sdf@gmail.com','2352345','2024-08-11 08:18:13'),(76,'demo','asdf','adsdf','adsfas','asdf','sdf@gmail.com','4234','2024-08-11 08:21:11'),(77,'demo','asdf','adsdf','adsfas','asdf','sdf@gmail.com','4234','2024-08-11 08:22:12'),(78,'contact','asdf','sdf','asdf','sadf','sadjf@gmakdfj.com','234','2024-08-11 08:22:57'),(79,'contact','test','test','test','test','test@gmail.com','23434234','2024-08-11 08:43:31');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey`
--

DROP TABLE IF EXISTS `survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `survey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_1` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `question_2` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `question_3` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `question_4` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `question_5` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `question_6` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `question_7` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `question_8` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `question_9` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `question_10` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `firstname` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `lastname` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `jobtitle` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `company` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `phone` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `insert_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey`
--

LOCK TABLES `survey` WRITE;
/*!40000 ALTER TABLE `survey` DISABLE KEYS */;
INSERT INTO `survey` VALUES (53,'1 - 25 users','< 25%>','Identity Theft','on','Cloud','4 – 5','26 – 50 % ','Reliability','16 + hours','','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-14 19:39:41'),(54,'1 - 25 users','< 25%>','Ransomware','on','Cloud','3 – 4','11 – 25 %','Delivery time frame','4 – 7 hours','','sunil','singh','developer','Bang Australia','sunilsingh2019@gmail.com','0452139110','2021-12-14 19:46:55'),(55,'1 - 25 users','< 25%>','Data Theft','Security','Cloud','6 +','51 + %','Vendor and Distributor support','16 + hours','on','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-14 19:49:32'),(56,'1 - 25 users','< 25%>','Ransomware','Cost','Users and access','1 – 2','<10 %','Delivery time frame','1 – 3 hours','Fortinet','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-14 19:51:52'),(57,'1 - 25 users','< 25%>','Ransomware','Reliability','Cloud','3 – 4','11 – 25 %','Delivery time frame','4 – 7 hours','Palo Alto','Bibek','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-14 22:02:53'),(58,'1 - 25 users','< 25%>','Ransomware','Cost','Users and access','1 – 2','26 – 50 % ','Deployment and Management simplicity','16 + hours','Palo Alto','sunil','singh','developer','skdjf','sunilsingQWERh2019@gmail.com','452139110','2021-12-14 23:00:27'),(59,'101+ users','26 - 50 %','Identity Theft','Ease of Management','All of the above','6 +','51 + %','Vendor and Distributor support','4 – 7 hours','Sophos','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-14 23:05:04'),(60,'101+ users','51+ %','Phishing','Ease of Management','All of the above','6 +','51 + %','Vendor and Distributor support','16 + hours','Palo Alto','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-14 23:09:45'),(61,'26 - 50 users','26 - 50 %','Identity Theft','Reliability','Network','4 – 5','26 – 50 % ','Deployment and Management simplicity','16 + hours','Palo Alto','sunil','singh','developer','skdjf','dfgewrt@gmail.com','452139110','2021-12-14 23:13:18'),(62,'51 - 100 users','< 25%>','Data Theft','Security','Cloud','3 – 4','26 – 50 % ','Deployment and Management simplicity','4 – 7 hours','Sophos','sunil','singh','developer','skdjf','dfgewrt@gmail.com','452139110','2021-12-14 23:24:31'),(63,'26 - 50 users','26 - 50 %','Data Theft','Security','Cloud','3 - 4','11 - 25 %','Margin','4 - 7 hours','Fortinet','sunil','singh','developer','skdjf','sunilsingh2019@gmail.com','0452139110','2021-12-15 20:00:35'),(64,'1 - 25 users','< 25%','Ransomware','Cost','Users and access','1 - 2','<10 %','Margin','1 - 3 hours','Fortinet','sunil','singh','developer','skdjf','sfafds@gmail.com','452139110','2021-12-15 20:17:31'),(65,'1 - 25 users','< 25%','Ransomware','Reliability','Users and access','1 - 2','<10 %','Delivery time frame','4 - 7 hours','Fortinet','sunil','singh','developer','skdjf','dfgewrt@gmail.com','452139110','2021-12-15 20:19:03');
/*!40000 ALTER TABLE `survey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `firstname` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `lastname` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `user_status` tinyint(1) NOT NULL,
  `user_level` tinyint(4) NOT NULL,
  `user_last_login` datetime NOT NULL,
  `mobile` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'sunilsingh2019@gmail.com','$2a$12$DuFR/41C4S.Y6eQP10eYeuz1T2.SwO2ZK.QhDG.sPgMHI4c6qZWd2','Sunil','Singh',1,1,'2024-08-11 08:43:45',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-11  8:46:49
